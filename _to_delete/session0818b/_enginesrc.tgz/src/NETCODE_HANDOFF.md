# NETCODE HANDOFF — online play for RLSW

> **Mission:** play RLSW online with friends — room codes, 2–4 players FFA,
> spectators, bot seat-fill, and reconnect. Built on the finished multiplayer
> foundation (see MULTIPLAYER_HANDOFF.md — all 8 phases ☑): a deterministic,
> serializable engine where `{ seed, config, log }` reproduces any game
> byte-for-byte.

## Architecture (decided 2026-07-09, owner-confirmed)

- **Topology: Node WebSocket server.** A small standalone Node program
  (`server/`) holds rooms and an open socket per browser. Localhost/LAN first,
  cheap cloud host later. Same language as the game; the engine itself is pure
  ESM with no React deps (selftest runs under plain `node`), so the server can
  import it for validation when we graduate to authority.
- **Authority: action-relay lockstep (v1).** The ACTING player's client runs
  the orchestration exactly as today and dispatches engine actions; the server
  sequences them (monotonic `seq`) and broadcasts; every other client applies
  the same actions in order. The server is a dumb, ordered pipe that remembers
  the log. Trusts the actor — fine for friends. **v2 (later): server authority**
  — the server runs `applyAction` itself and validates; requires graduating the
  remaining client-side rules (VIBE_CHANGED, SPIRIT_MOVED, event orchestration)
  into reducers first. The protocol below is designed so v2 changes the server,
  not the message shapes.
- **v1 scope:** room codes · 2–4 player FFA · spectators · human+bot mix ·
  reconnect (spectator catch-up and rejoin are the same machinery).

## The contract the foundation already gives us

- `dispatch` (Game, ~L633) is the SINGLE choke point: every engine write goes
  through it and is appended to `actionLogRef` as `{ action, cursorBefore }`.
  The relay hook lives here and nowhere else.
- `makeInitialState(config, seed)` + the log = byte-identical replay (Phase 8c
  selftest). The 💾 EXPORT ACTION LOG bundle `{ schema, seed, config,
  actionCount, log }` IS the catch-up payload.
- `cursorBefore` is a free per-action DESYNC TRIPWIRE: before applying a remote
  action, compare local `rng.cursor` to the sender's `cursorBefore`; mismatch =
  divergence → freeze input, request CATCH_UP, log loudly.
- All client `Math.random` outcomes already ride in payloads
  (RIFF_RESULTS_SUBMITTED pattern) — remote replay never re-rolls. **Invariant
  for all new code: outcomes in payloads, never re-computed on remote clients.**

## Protocol (JSON frames over ws)

Client → server:
`CREATE_ROOM { name, schema, appVersion }` · `JOIN_ROOM { code, name,
spectator?, rejoinToken?, schema, appVersion }` (N8: schema must match the
server's, appVersion must match the room creator's — explicit mismatch =
`VERSION_MISMATCH`, refused at the door; version-less frames are tolerated)
· `START_GAME { config }` (host only; server injects `seed`) · `ACTION
{ action, cursorBefore }` (acting seat only) · `LOG_LINE { text }`
(presentation side-channel) · `REQUEST_CATCHUP {}` (N8: desync recovery —
answered with the same CATCH_UP bundle a late joiner gets) · `RETURN_TO_LOBBY {}`
(N10: any seated player; resets the room to phase:lobby — wipes log/seed/config,
drops bot seats, keeps human seats + rejoin tokens — and broadcasts
RETURNED_TO_LOBBY so every client drops back to the lobby together) ·
`BOOT_PLAYER { seatId }` (N11: host-only, lobby-only — removes the seat and its
token; a live target gets `BOOTED` and its socket closed) · `LEAVE` (in the
lobby this now frees the seat immediately; mid-game the seat survives
disconnected for token rejoin) · `PING`.

Server → client:
`ROOM_STATE { code, you, seats[], spectators, phase }` · `GAME_STARTED { seed,
config, seats }` · `ACTION { seq, seatId, action, cursorBefore }` · `LOG_LINE
{ seq, seatId, text }` · `CATCH_UP { seed, config, seats, log, logLines }` ·
`RETURNED_TO_LOBBY {}` (N10) · `BOOTED { msg }` (N11: you were removed — the
client must clear its session or auto-reconnect sneaks it back in) ·
`ERROR { code, msg }` · `PONG`.

N11 seat lifecycle: lobby seats are no longer immortal. Explicit LEAVE removes
the seat instantly; a silent disconnect in the lobby starts a linger timer
(`LOBBY_LINGER_MS`, default 45s — F5 grace window, token rejoin cancels it)
after which the ghost seat is dropped and broadcast. Host leaving migrates
hostship to the next human seat. seatIds are allocated max+1 (removals leave
gaps, so length+1 would collide). Mid-game seats still survive indefinitely.

N10 client contract: leaving the Game closes the socket WITHOUT clearing the
saved session (`client.close()`, not `leave()`), so the Lobby's auto-rejoin
reclaims the seat in the room's now-reset lobby. Server-side, a rejoin token
reclaims its seat even if a stale socket is still attached (the old socket is
terminated) — without this, a return-to-lobby or fast F5 raced the old
connection and dumped the player into spectator mode of a dead game.

Server state per room: `{ code, phase: lobby|playing, seats[{ seatId, name,
spiritId?, connected, rejoinToken, isBot }], spectators, seed, config, log[],
logLines[], seq }`. Rooms die 10 min after the last socket drops.

## Phases

| # | Phase | Exit criterion | Status |
|---|-------|----------------|--------|
| N0 | Seed threading | `gameState.seed` reaches `makeInitialState`; offline unchanged | ☑ |
| N1 | Room server skeleton | node smoke script: create/join/relay/catch-up green | ☑ |
| N2 | Net client + lobby UI | two tabs see each other in a room | ☑ |
| N3 | Start handshake | both tabs boot the SAME game (seed+config from server) | ☑ |
| N4 | Action relay | full 2-human match across two tabs | ☑ |
| N5 | Presentation relay | remote log lines + acceptable remote visuals | ☑ |
| N6 | Spectate + reconnect | spectator joins mid-game; player F5s and resumes | ☑ |
| N7 | Bot seats | 1 human + bots online; bot actions relay like human ones | ☑ |
| N8 | Hardening | version check, heartbeats, dev-panel gating, desync UX | ☑ |
| N9 | Deploy | play over the internet | ☑ |

- **N0 — seed threading (one line + lobby plumbing).**
  `makeInitialState(gameState)` currently defaults `seed = Date.now()>>>0`
  (state.js L26). Change the Game init to `makeInitialState(gameState,
  gameState.seed)` — undefined keeps today's default, so offline is
  byte-unchanged. Online, `GAME_STARTED.seed` rides into `gameState`.
- **N1 — room server skeleton.** `server/` (own package.json, dep: `ws`).
  Rooms, 4-letter codes, seats, sequencing, broadcast, CATCH_UP, rejoin
  tokens, LOG_LINE relay, heartbeat sweep. NO game knowledge (v1). Smoke
  script `server/smoke.mjs` drives 3 fake clients end-to-end. **Scaffolded —
  see server/README.md; `npm i && npm test` inside server/.**
- **N2 — net client + lobby UI.** `src/net/client.js`: tiny ws wrapper
  (connect, send, on, auto-reconnect with backoff, rejoinToken in
  localStorage). Lobby gains "Play online": create room (shows code) / join
  code / seat list / ready. Keep the offline path 100% untouched — online is
  additive UI state.
- **N3 — start handshake.** Host configures the lineup in the existing Lobby
  (config shape already = `makeInitialState`'s first arg, proven by the export
  bundle); server stamps `seed` and broadcasts GAME_STARTED; every client
  calls `onStart({ ...config, seed, net })`. Remote clients boot the identical
  engine state. Exit check: both tabs' `engineState.rng.seed` and initial
  snapshot hashes match (log them).
- **N4 — action relay (the heart).** In `dispatch`: if online and this client
  controls `engineState.acting`, apply locally (unchanged synchronous return —
  timeout chains keep working) AND send ACTION. Remote ACTION frames go
  through `applyRemote(action, cursorBefore)`: verify cursor, `applyAction`,
  `setEngineState`, append local log. NEVER run orchestration for remote
  actions — no addLog, no FX, no timeouts (presentation comes from N5).
  Input gating: disable action UI when `acting` isn't yours (read seat→spirit
  map from GAME_STARTED). Server enforces sender==acting-seat loosely by
  tracking TURN_STARTED/TURN_ENDED in the stream (lite validation, v1).
- **N5 — presentation relay.** Remote board/HUD largely renders itself —
  spirits, noteStates, board hexes, battle + riff slices are all engine state
  now (that was the point of the flip). Relay `addLog` lines via LOG_LINE so
  everyone reads the same story. Accept degraded remote cinematics v1 (results
  without every dice-spin frame); note gaps during smoke tests and promote the
  worst offenders to engine `turn.last*` reports later, not ad-hoc FX messages.
- **N6 — spectate + reconnect (same machinery).** Any JOIN mid-game (spectator
  or returning seat, matched by rejoinToken) gets CATCH_UP `{ seed, config,
  log }` → client builds initial state and replays the log at max speed with
  presentation suppressed (engine replay is cheap — selftest replays hundreds
  of actions instantly), then resumes live. F5 = disconnect + rejoin, free.
- **N7 — bot seats.** Host's lobby marks empty seats as bots. The bot step
  machine already runs client-side and dispatches through the same choke
  point — gate it to run ONLY on the host's client, only for bot seats; its
  actions relay like any other. (Bot decisions read engine state and bot rolls
  use engine rng, so replay stays exact — the step machine's setTimeout pacing
  is presentation, sequenced by the server like everything else.)
- **N8 — hardening. ☑ Shipped 2026-07-12** (smoke: `server/n8-hardening-smoke.mjs`):
  - **Version handshake:** CREATE/JOIN carry `{ schema, appVersion }`
    (`CLIENT_SCHEMA` in net/client.js; `__APP_VERSION__` injected by vite from
    package.json, "dev" under node). Server refuses explicit mismatches with
    `VERSION_MISMATCH`; the room pins the creator's appVersion.
  - **Desync UX:** cursor mismatch OR a seq gap (every ACTION frame, echoes
    included, must arrive at lastSeq+1) → freeze input (`canAct` false, bot
    step machine halted), send REQUEST_CATCHUP, banner "⚠️ OUT OF SYNC".
    The Game-level CATCH_UP handler rebuilds the engine from seed+config+log
    (same machinery as the N6 mount replay) and unfreezes. This also heals
    wifi blips: the client auto-rejoins and the server's WELCOME+CATCH_UP now
    lands in-game, not just in the lobby.
  - **Presence banners:** in-game ROOM_STATE listener → "🔌 X disconnected
    (reconnecting…)" per dropped human seat; own-socket net:close/net:open →
    "📡 CONNECTION LOST". Server heartbeat sweep (15s ping/pong) was already
    killing zombies so seats flip `connected` promptly.
  - **Dev gating:** Testing Grounds launch button hidden while in a room;
    in-game `testMode` is hard-false when `gameState.net` exists (config rides
    the wire — a flag must not enable dev grants online).
  - **SYNC tripwires:** the SPIRITS_SYNCED / NOTE_STATES_SYNCED full-replace
    fallbacks console.error + post a 🚨 log line if they ever fire online.
  - **Ownership fix (same day):** the skill/upgrade tree is now controllable
    ONLY by the client that controls the acting spirit — UpgradeModal renders
    behind `canAct`, and the initial-pick effect, `setSkillTarget`, `placeAmp`
    + the Place-Amp chip are `canAct`-gated (remote clients previously drove
    other players' trees AND relayed duplicate NOTE_SHEET_PATCHED writes).
- **N9 — deploy. ☑ Shipped 2026-07-12.**
  **What was done:**
  - `__SERVER_URL__` wired into vite.config.js (`process.env.SERVER_URL`) and
    net/client.js (`BAKED_SERVER_URL`). Priority: `?server=` query > baked URL >
    LAN fallback. Build with
    `SERVER_URL=wss://rlsw-server.onrender.com npm run build` to bake a
    production default; `?server=` still overrides for testing.
  - Dockerfile + render.yaml + .dockerignore in `server/` — Render deployment:
    free tier, no credit card, auto-TLS on `*.onrender.com`.
  - Server upgraded to HTTP+WebSocket (N9): `http.createServer` handles health
    checks at `/health`; WebSocket upgrades on the same port. Required by
    Render (and most PaaS) which route all traffic through one HTTP port.
  **Deploy commands:**
  ```
  # 1. Server — push to GitHub, then in Render Dashboard:
  #    New → Web Service → connect repo → set Root Directory to "server"
  #    → pick Free plan → Deploy.
  #    Or use the render.yaml blueprint: New → Blueprint → connect repo.
  #
  # 2. Client (gh-pages, baking the server URL into the build):
  #    (Windows)
  set SERVER_URL=wss://rlsw-server.onrender.com&& npm run build && npm run deploy
  #    (macOS/Linux)
  SERVER_URL=wss://rlsw-server.onrender.com npm run build && npm run deploy
  ```
  **LAN (no deploy needed):** `npx vite --host` + `cd server && node index.js`.
  Gotchas addressed:
  1. **Mixed content (wss mandatory):** `*.onrender.com` gets TLS automatically.
     `defaultServerUrl()` already picks `wss:` when the page is served over
     https.
  2. **LAN-only default:** `BAKED_SERVER_URL` replaces the hostname fallback
     when set. Build without `SERVER_URL` and the old LAN behavior is unchanged.
  3. **Sleeping hosts:** Render free tier sleeps after 15 min of zero inbound
     traffic. Active WebSocket connections (heartbeat pings) count as traffic,
     so the server stays awake during games. First connection after idle has a
     ~30s cold start — rooms from before the sleep are gone (RAM), but the
     grave timer already kills them 10 min after the last disconnect anyway.
     No credit card, no surprise charges — if you exceed the 750 hr/mo free
     cap, service is suspended, not billed.

- **N13 — live-play bug sweep. ☑ Shipped 2026-08-05** (three reports from a
  friends game; all three were the same root cause wearing different hats —
  *presentation lives outside the engine and nothing was rebuilding it*).
  - **Rival melodies were silent.** `confirmNoteTrack` plays the committed
    track on the acting client only. The commit's LAST action is
    MOVE_BUDGET_SET, and by the time it lands the track is already engine state
    (`committedMelody` / `committedFreq` / `committedHasRiff`, stashed by
    NOTE_SHEET_PATCHED) — so the relay branch replays it from state. No new
    frame type, no payload change, deterministic on every client.
    *Pattern to reuse: for remote audio/FX, find the action that lands AFTER
    the state the effect needs, then read the state — don't invent a frame.*
  - **The rival's HUD was live and clickable.** `turnStep` (chord → melody →
    move_act) is local React state whose only reset lived in `endTurn`, which
    is canAct-gated — so it ran on the ACTING client alone. Clicking "Continue
    to Melody" on a rival's panel therefore advanced YOUR step permanently and
    your next turn opened past the chord stack. Fixed twice over: the step is
    now anchored to `engineState.acting` (every client resets when the turn
    passes), and the acting panel renders a read-only "🎧 rival is on stage"
    card when `!canAct` — stock, stack notes and the action rail are hidden or
    pointer-events:none. **Visibility rule (owner's call): the PERFORMANCE is
    public, the PLANNING is private.** The melody bar, the ⚔️/🛡️ totals and
    the board are shared; the note stock, the stack being voiced and pending
    actions are not, until they're played.
  - **The online riff-off hung at the handoff.** The duel advanced only on the
    ARRIVAL of one relay frame, so anything that ate that frame (desync freeze
    + CATCH_UP, a blip, a Round-1 `waitingForResolve` left standing) stranded
    the defender on "waiting for the call" and the attacker on "waiting for
    rival" with no way out. Three fixes: CATCH_UP now **rebuilds the battle
    overlay** from the engine battle slice (it was explicitly not rebuilding
    presentation — fine for a camera, fatal for a duel); a **phase-repair
    effect** derives whose turn it is from `battle.atkResults` / `defResults`
    on every engine change rather than from an event; and a 30s **watchdog**
    requests a CATCH_UP if a client is still waiting on the other machine.
    Also fixed: a bot ATTACKER on the host never resolved (`isAtkClient`
    compares mySpiritId, which never matches a bot seat).
  - **Drive-by:** `hasRig` in the Displace button label was undefined —
    a ReferenceError into the error boundary the moment Intergalactic 0
    unlocked Displace. Predates the netcode work; caught by eslint `no-undef`.
    Worth running that lint pass over the main file more often.

## Landmines (read before each phase)

1. **Remote clients replay, never re-run.** The acting client's timeout chains
   (knockback slides, battle beats) emit actions over wall-clock time; the
   server's seq order IS the truth; remote clients apply in order as frames
   arrive. Any new randomness must ride in the payload.
2. **Game remount key.** `<Game key={JSON.stringify(gameState.spirits…)}>`
   (App ~L609) remounts Game when the lineup changes — make sure GAME_STARTED
   produces exactly one mount, and CATCH_UP does not remount mid-replay.
3. **`spirits`/`noteStates` shims.** Legacy writes still flow through the
   diffing shims → SPIRIT_PATCHED / NOTE_SHEET_PATCHED. That's replay-safe by
   construction, but shim writes on a REMOTE client's machine would fork
   reality — they can only ever run inside orchestration, which only the
   acting client runs (invariant #1 again; the N8 tripwire catches violations).
4. **Fast-forward (⏩) is per-client presentation** — safe to leave as is;
   never let it scale anything that emits actions on a non-acting client.
5. **Rooms are RAM.** Server restart kills games (v1 accepted). The CATCH_UP
   bundle is JSON — trivially persistable later if it ever matters.
6. **Winner + Rock God edges.** Two non-combat `setWinner` sites don't shadow
   WINNER_DECLARED yet (MULTIPLAYER_HANDOFF §5c tail) — harmless for relay
   (clients converge via the log) but fold them in during N5 so remote HUDs
   read `engineState.winner` too.
7. **Presentation is not replicated — derive it, don't relay it.** (N13) The
   engine converges on every client for free; React state does not. Any overlay
   that gates play (battle cards, phase handoffs) must be derivable from
   `engineState` and re-derived after CATCH_UP, or a single dropped frame ends
   the game. Anything gated behind an event handler alone is a stall waiting to
   be reported.
8. **Local-only controls still need `canAct`.** (N13) Handlers that dispatch
   were gated from N4; handlers that only move HUD state were not, and one of
   them (`setTurnStep`) silently desynced the player's own turn flow. If a
   control mutates anything while a rival is acting, it needs the gate too.
