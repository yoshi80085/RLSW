// ─── ENGINE SYSTEM: COMBAT ───────────────────────────────────────────────────
// Phase 3a: the pure combat MATH — damage/knockback/fame tables — extracted
// verbatim from Game so a server can score battles identically. No actions,
// no state mutation, no timers yet: those land in 3b–3e (rolls → DAMAGE_APPLIED
// → KNOCKBACK_MOVED → KNOCKED_OUT → RETALIATION_*). `Game` imports these the
// same way it imports `riffStats` — single source of truth for the tables.

import {
  UNDERDOG_MIN_DEFICIT, UNDERDOG_DEFICIT_PER_STEP, UNDERDOG_MAX_MULT,
  THRASH_DAMAGE_CAP, THRASH_WHIFF_DMG, THRASH_PUSH_THRESHOLD,
  SONIC_VIBE_CAP,
} from "../../data/gameConstants.js";
import { CORNERS } from "../../data/corners.js";
import { cornerFacing } from "../../board/boardHelpers.js";
import { isPosing, applyPoseSet } from "./limelight.js";

/**
 * LEGACY damage table — still used by Smash, riff-off, and any call site that
 * hasn't been split yet. New code should use thrashDamage / sonicDamage.
 */
export function marginToDamage(margin) {
  if (margin <= 3)  return 1;
  if (margin <= 6)  return 2;
  if (margin <= 9)  return 3;
  if (margin <= 12) return 4;
  return 5;
}

// ─── THRASH (melee) ──────────────────────────────────────────────────────────
/**
 * Thrash Vibe damage — the heavy hitter. Drive/Sustain is the real driver;
 * a Spirit who's burned their chord stack and dropped Sustain will eat it bad.
 * Clean 2-wide bands keep the curve readable, capped at THRASH_DAMAGE_CAP (4).
 *   margin 1-2 = 1,  3-4 = 2,  5-6 = 3,  7+ = 4 (cap)
 * @param {boolean} isAttackerLoss  true when the ATTACKER lost — caps at THRASH_WHIFF_DMG (1).
 */
export function thrashDamage(margin, isAttackerLoss = false) {
  if (isAttackerLoss) return THRASH_WHIFF_DMG;
  if (margin <= 2) return 1;
  if (margin <= 4) return 2;
  if (margin <= 6) return 3;
  return THRASH_DAMAGE_CAP;
}

/**
 * Thrash knockback — minimal positional displacement, but ALWAYS non-zero on a
 * hit. Landing a Swing is earned: you get the hex, however narrow the win. The
 * push stays flat at 1 (vs Sonic's 1-5) so Sonic remains the positional weapon;
 * Thrash just gets its due for kicking a rival off the spot they were holding.
 */
export function thrashKnockback(margin) {
  return margin >= THRASH_PUSH_THRESHOLD ? 1 : 0;
}

/** Thrash FP — fighting earns almost no Fame; you fight to hurt, not to shine. */
export function thrashFame() {
  return 1;
}

// ─── SONIC (ranged) ──────────────────────────────────────────────────────────
/**
 * Sonic Vibe damage — the beam stings but doesn't destroy. Capped at
 * SONIC_VIBE_CAP (2). Most hits deal 1.
 */
export function sonicDamage(margin) {
  if (margin <= 4) return 1;
  return Math.min(SONIC_VIBE_CAP, 2);
}

/**
 * Sonic knockback — the main positional weapon. Base push from margin (1-3),
 * plus a Vibe-deficit bonus: a battered rival gets launched further.
 */
export function sonicKnockback(margin, vibe, maxVibe) {
  vibe = vibe ?? 1;
  maxVibe = maxVibe ?? 1;
  const baseKB   = Math.min(3, Math.max(1, Math.ceil(margin / 2)));
  const vibeRatio = Math.max(0, 1 - (vibe / Math.max(1, maxVibe)));
  const vibeKB    = Math.floor(vibeRatio * 2);
  return Math.min(5, baseKB + vibeKB);
}

/**
 * Sonic FP — the primary Fame engine. Scales directly with margin so the
 * Drive/Sustain gap you built matters. Bigger wins = bigger legend.
 */
export function sonicFame(margin) {
  return Math.max(1, Math.ceil(margin / 2));
}

// ─── LEGACY knockback / fame (kept for Smash, riff-off, etc.) ────────────────
export function knockbackSpaces(bs, margin) {
  const m = margin ?? bs?.margin ?? 1;
  return bs?.sonicAttack ? Math.min(3, Math.max(1, Math.ceil(m / 2))) : 1;
}

export function fameFromMargin(margin) {
  if (margin <= 3) return 1;
  if (margin <= 6) return 2;
  return 3;
}

/**
 * Underdog / comeback amplifier — pure over the two Fame totals.
 */
export function underdogBonus(winnerFame, loserFame, baseFp) {
  const deficit = loserFame - winnerFame;
  if (deficit < UNDERDOG_MIN_DEFICIT) return { fp: baseFp, deficit: 0, mult: 1 };
  const mult = Math.min(UNDERDOG_MAX_MULT, 1 + (deficit / UNDERDOG_DEFICIT_PER_STEP) * 0.5);
  let fp = Math.round(baseFp * mult);
  const maxFp = Math.max(baseFp, deficit);
  fp = Math.min(fp, maxFp);
  return { fp, deficit, mult };
}

// (Phase 3d counter/retaliation rolls REMOVED — the Stance rework replaces the
// counter mechanic with natural Thrash-adjacency retaliation; §3/§8 of
// STANCE_SYSTEM_DESIGN.md.)

/**
 * decideWinner (Phase 3c kernel) — boss-aware win check.
 */
export function decideWinner(spirits, { godSummoned = false, attackerId = null, hasWinner = false } = {}) {
  const survivors = spirits.filter(s => !s.knockedOut);
  if (godSummoned && !hasWinner) {
    return { winnerId: null, godTriumphs: survivors.length === 0 };
  }
  if (survivors.length === 1) return { winnerId: survivors[0].id, godTriumphs: false };
  if (survivors.length === 0 && attackerId) {
    const atk = spirits.find(s => s.id === attackerId && !s.knockedOut);
    if (atk) return { winnerId: atk.id, godTriumphs: false };
  }
  return { winnerId: null, godTriumphs: false };
}

/**
 * resolveKnockdown (Phase 3c kernel) — respawn/KO state transform.
 */
export function resolveKnockdown(spirit, corners = CORNERS) {
  const livesLeft = (spirit.lives ?? 1) - 1;
  if (livesLeft > 0) {
    const homeNum   = spirit.corner ? corners[spirit.corner]?.homeNum : spirit.num;
    const newFacing = spirit.corner ? cornerFacing(homeNum) : spirit.facing;
    return {
      respawned: true, livesLeft,
      next: { ...spirit, lives: livesLeft, num: homeNum, facing: newFacing, vibe: spirit.maxVibe },
    };
  }
  return { respawned: false, livesLeft: 0, next: { ...spirit, lives: 0, knockedOut: true } };
}

/**
 * DAMAGE_APPLIED (Phase 5c) — subtract Vibe from target, floored at 0.
 */
export function applyDamageApplied(state, action) {
  const { targetId, dmg = 0 } = action;
  return {
    ...state,
    spirits: state.spirits.map(s =>
      s.id === targetId ? { ...s, vibe: Math.max(0, (s.vibe ?? 0) - dmg) } : s),
  };
}

/**
 * KNOCKDOWN_RESOLVED (Phase 5c) — apply resolveKnockdown transform.
 *
 * ✨ HITTING THE FLOOR ENDS THE POSE, WHEREVER THE BODY LANDS, and this is the
 * third of the three drop sites (the other two are walking out of the middle and
 * being shoved out of it — `movement.js` and `battleFlow.js`). Lifted in from
 * the client 2026-08-17: without it a Spirit knocked down IN the Limelight keeps
 * `posing` set and therefore keeps rolling a zero defence die THROUGH THEIR
 * RECOVERY TURN, which is the worst possible moment for it.
 *
 * 📌 The banked rounds survive, like every other way of leaving the middle.
 */
export function applyKnockdownResolved(state, action, corners = CORNERS) {
  const { targetId } = action;
  const spirit = state.spirits.find(s => s.id === targetId);
  if (!spirit) return state;
  const { next } = resolveKnockdown(spirit, corners);
  const dropped = isPosing(state, targetId)
    ? applyPoseSet(state, { spiritId: targetId, on: false })
    : state;
  return {
    ...dropped,
    spirits: dropped.spirits.map(s => (s.id === targetId ? next : s)),
  };
}

/**
 * WINNER_DECLARED (Phase 5c) — lock in the match winner.
 */
export function applyWinnerDeclared(state, action) {
  return { ...state, winner: action.winnerId ?? null };
}

/**
 * THE SMASH (Phase 3b) — deterministic, undefendable melee.
 */
export function smashOutcome(thrown) {
  const damage    = Math.min(5, Math.max(1, Math.ceil(thrown / 2)));
  const knockback = Math.min(3, Math.ceil(thrown / 3));
  const scatterN  = Math.floor(thrown / 2);
  return { damage, knockback, scatterN };
}

/**
 * ATTACK_ROLLED (Phase 3b) — roll attack dice on the engine's seeded rng.
 * Swing = single die (d4 base for Thrash, or atkDie). Sonic = keep-highest pool.
 * Defender rolls defDie (d4 for Thrash, d6 for Sonic).
 */
export function applyAttackRolled(state, action, rng) {
  const {
    kind, attackerId, defenderId,
    atkStat = 0, defStat = 0, posing = false, halveDef = false,
    dicePool = null, atkFloor = 0, atkDie = 6, defDie = 6,
    swingChordLeft = [], swingChordSpent = [],
  } = action;

  const clampFloor = v => Math.max(v, 1 + atkFloor);

  let atkRoll, diceVals = null, keptIdx = null;
  if (dicePool && dicePool.length) {
    diceVals = dicePool.map(sides => clampFloor(rng.int(sides) + 1));
    atkRoll  = Math.max(...diceVals);
    keptIdx  = diceVals.indexOf(atkRoll);
  } else {
    atkRoll  = clampFloor(rng.int(atkDie) + 1);
  }

  const rawDefRoll = posing ? 0 : rng.int(defDie) + 1;
  let   defRoll    = posing
    ? 0
    : (halveDef ? Math.max(1, Math.floor(rawDefRoll / 2)) : rawDefRoll);

  // (Psycho Bushido stun removed — Ronin rework: now a dash attack)

  const atkTotal    = atkStat + atkRoll;
  const defTotal    = posing ? 0 : defStat + defRoll;
  const attackerWon = atkTotal > defTotal;
  const margin      = Math.abs(atkTotal - defTotal);

  // Damage splits by attack kind
  const damage = kind === 'sonic'
    ? sonicDamage(margin)
    : kind === 'swing'
      ? thrashDamage(margin, !attackerWon)
      : marginToDamage(margin);

  return {
    ...state,
    battle: {
      kind: "attack", attackKind: kind,
      attackerId, defenderId, atkStat, defStat,
      atkRoll, diceVals, keptIdx, rawDefRoll, defRoll, defDie,
      atkTotal, defTotal, attackerWon, margin, damage,
      // Preserved so ATTACK_REROLLED can redo the attacker's draw with the
      // exact same dice shape it was originally rolled with.
      dicePool, atkFloor, atkDie,
      // 🎸 The Swing's deferred chord burn, carried so `battleConsequences` can
      // spend it on a hit. ⚠️ It lives on `state.battle` rather than only in the
      // caller's hand for the same reason the reroll payload does: every
      // consumer that drives the aftermath from engine state — the bot's
      // transition, a server, a replay — must see the same price. It did not
      // until 2026-08-17, and because `battleConsequences` defaults both to
      // `[]`, the omission burned nothing and said nothing.
      swingChordLeft, swingChordSpent,
      rerolled: false,
    },
  };
}

/**
 * ATTACK_REROLLED (Code Injection — Intergalactic 0) — re-draw the ATTACKER'S
 * dice and re-resolve the whole verdict. The defender's roll is untouched.
 *
 * ⚠️ WHY THIS HAS TO BE A REDUCER AND NOT A CLIENT-SIDE RE-SPIN. A whole battle
 * — both rolls, the winner, the margin AND the damage — is decided in ONE
 * ATTACK_ROLLED action, up front; the battle overlay merely ANIMATES a result
 * that already exists in engine state. So "re-roll the dice" cannot mean
 * spinning a number on screen: every downstream figure has to be recomputed, and
 * it has to be recomputed from the SEEDED rng or online clients desync (they
 * compare rng cursors frame-by-frame and freeze on a mismatch).
 *
 * Damage is recomputed with the same kind-split as the original roll, so a
 * Thrash whiff still pays THRASH_WHIFF_DMG back at the attacker.
 *
 * Idempotence is NOT provided on purpose: Code Injection is once per commit, and
 * the caller owns that gate. `rerolled: true` is set so the overlay can label
 * the result, not to block a second call.
 */
export function applyAttackRerolled(state, action, rng) {
  const b = state.battle;
  if (!b || b.kind !== "attack") return state;

  const clampFloor = v => Math.max(v, 1 + (b.atkFloor ?? 0));

  let atkRoll, diceVals = null, keptIdx = null;
  if (b.dicePool && b.dicePool.length) {
    diceVals = b.dicePool.map(sides => clampFloor(rng.int(sides) + 1));
    atkRoll  = Math.max(...diceVals);
    keptIdx  = diceVals.indexOf(atkRoll);
  } else {
    atkRoll  = clampFloor(rng.int(b.atkDie ?? 6) + 1);
  }

  // The defender's side of the maths is deliberately reused verbatim — Code
  // Injection rewrites the RIVAL'S roll, never your own defence.
  const atkTotal    = (b.atkStat ?? 0) + atkRoll;
  const defTotal    = b.defTotal ?? 0;
  const attackerWon = atkTotal > defTotal;
  const margin      = Math.abs(atkTotal - defTotal);

  const damage = b.attackKind === 'sonic'
    ? sonicDamage(margin)
    : b.attackKind === 'swing'
      ? thrashDamage(margin, !attackerWon)
      : marginToDamage(margin);

  return {
    ...state,
    battle: {
      ...b,
      atkRoll, diceVals, keptIdx,
      atkTotal, attackerWon, margin, damage,
      rerolled: true,
      // Kept for the log line / overlay tell: what the attack WOULD have done.
      preRerollAtkRoll:  b.atkRoll,
      preRerollWon:      b.attackerWon,
      preRerollDamage:   b.damage,
    },
  };
}

// ─── 🔪 THE REAR ARC ────────────────────────────────────────────────────────
// A Spirit's facing already gates what they can ATTACK (getSwingCone, the Sonic
// beam). This is the other half of that bargain: facing also decides what they
// can BRACE against. Catch a rival in the wedge behind them and the blow lands
// on an unguarded back — their Sustain stack sheds an extra note.
//
// Geometry: the rear wedge is everything more than 120° off the defender's
// facing, i.e. 60° to either side of directly-behind. That is deliberately
// NARROWER than "not in their front cone" — flanking is not backstabbing, and
// a defender shouldn't be punished for every attacker they aren't staring at.
// One hex of FACE (1 AP) is always enough to close the wedge, which is what
// makes it a real decision rather than a positional tax.
export const REAR_ARC = (2 * Math.PI) / 3;   // >120° off facing = behind them
export const REAR_FRAY_BONUS = 1;            // extra Sustain notes stripped

/**
 * Is the attacker standing in the defender's rear wedge? (pure)
 *   defenderFacing — the defender's facing angle, radians
 *   angleToAttacker — angle from the DEFENDER's hex to the ATTACKER's hex
 * Both angles are screen-space atan2 (see hexGeometry.angleTo), so the caller
 * must not pre-normalise them; `diffFn` handles the wrap.
 */
export function isRearHit(defenderFacing, angleToAttacker, diffFn) {
  if (defenderFacing == null || angleToAttacker == null) return false;
  return diffFn(angleToAttacker, defenderFacing) > REAR_ARC;
}

/**
 * Chord-fray arithmetic (pure). Style-NEUTRAL base fray from the hit margin —
 * moved verbatim from data/stances.js (was `stanceFrayAmount`) when Stances
 * were cut in favor of the Style system (STYLE_SYSTEM_HANDOFF.md). Returns
 * the note count to strip (before the "1 note always survives" floor, which
 * the caller owns).
 *   margin ≤ 2 → 1 note
 *   margin ≥ 3 → 2 notes
 *   + REAR_FRAY_BONUS when the blow came from the defender's rear wedge
 *
 * ⚠️ The floor still belongs to the caller, so a backstab can never bleed a
 * stack to nothing — it just gets there faster.
 */
export function chordFrayAmount(margin, fromBehind = false) {
  return (margin >= 3 ? 2 : 1) + (fromBehind ? REAR_FRAY_BONUS : 0);
}

// ─── DRIVE / SUSTAIN STACK SPLIT: SPEND HELPERS ─────────────────────────────
// Pure functions — compute the stack mutations for an attack's note costs.
// The caller applies the returned patches to the noteStates.
//
// Rules (§5 of DRIVE_SUSTAIN_SPLIT_DESIGN.md):
//   Sonic:    attacker spends 1 from Drive (hit or miss); defender loses 1 from Sustain on hit.
//   Physical: attacker spends 2 from Drive on hit only;   defender loses 1 from Sustain on hit.

/**
 * Sonic attack spend — attacker always pays 1 from driveStack.
 * Returns { driveStack } patch (last note popped) or null if Drive is empty.
 */
export function sonicDriveSpend(driveStack) {
  if (!driveStack || driveStack.length === 0) return null;
  return { driveStack: driveStack.slice(0, -1) };
}

/**
 * Physical (swing) attack spend — attacker pays 2 from driveStack ON HIT ONLY.
 * Returns { driveStack } patch or null if not enough notes (need ≥ 2).
 */
export function physicalDriveSpend(driveStack) {
  if (!driveStack || driveStack.length < 2) return null;
  return { driveStack: driveStack.slice(0, -2) };
}

/**
 * Defender sustain chip — defender loses 1 note from sustainStack on hit.
 * Returns { sustainStack } patch or null if Sustain is empty.
 */
export function sustainChip(sustainStack) {
  if (!sustainStack || sustainStack.length === 0) return null;
  return { sustainStack: sustainStack.slice(0, -1) };
}

/**
 * Fray — strips notes from the defender's Sustain Stack (post-roll, on hit).
 * Returns { sustainStack } patch. At least 1 note always survives.
 */
export function frayFromSustain(sustainStack, amount) {
  if (!sustainStack || sustainStack.length <= 1) return { sustainStack: sustainStack || [] };
  const fray = Math.min(amount, sustainStack.length - 1);
  return { sustainStack: sustainStack.slice(0, sustainStack.length - fray) };
}

/**
 * Finisher stack-wipe — wipes BOTH stacks on the target.
 * 'obliterate': clears both completely.
 * 'scatter': removes `scatterN` notes from each stack (proportionally).
 * Returns { driveStack, sustainStack } patch.
 */
export function finisherStackWipe(driveStack, sustainStack, wipeType, scatterN = 0) {
  if (wipeType === 'obliterate') {
    return { driveStack: [], sustainStack: [] };
  }
  // scatter: remove up to scatterN from each, keeping at least 0
  const newDrive   = (driveStack   || []).slice(0, Math.max(0, (driveStack?.length ?? 0)   - scatterN));
  const newSustain = (sustainStack || []).slice(0, Math.max(0, (sustainStack?.length ?? 0) - scatterN));
  return { driveStack: newDrive, sustainStack: newSustain };
}
