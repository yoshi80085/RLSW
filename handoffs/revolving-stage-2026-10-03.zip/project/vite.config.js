export default { base: '/RLSW/' };
