import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { ALL_HEXES, HEX_BY_NUM } from '../../src/board/hexMap.js';
import { createStandee, STANDEE } from '../../src/board/standee.js';
import { SPIRIT_DEFS } from '../../src/data/spirits.js';

const clamp = THREE.MathUtils.clamp;
const world = n => { const h = HEX_BY_NUM[n]; return new THREE.Vector3((h.px-3255)/200, .2, (h.py-2415)/200); };
const hash = n => { const v = Math.sin(n*127.1+311.7)*43758.5453; return v-Math.floor(v); };
const homes = new Map([[7,0x75cfff],[12,0xc599ff],[100,0xe7d784],[105,0xff9569]]);
function shape(r, seed=0, jagged=false) {
  const s = new THREE.Shape();
  for(let i=0;i<6;i++) { const a=i*Math.PI/3, rr=r*(jagged ? .88+hash(seed+i)*.17 : 1); s[i?'lineTo':'moveTo'](Math.cos(a)*rr,Math.sin(a)*rr); }
  s.closePath(); return s;
}
function lineHex(r,y,color,opacity=1) {
  const pts=Array.from({length:7},(_,i)=>new THREE.Vector3(Math.cos(i*Math.PI/3)*r,y,Math.sin(i*Math.PI/3)*r));
  return new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color,transparent:true,opacity,toneMapped:false}));
}
export function createStage(host, prefs, onSettled) {
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.6)); renderer.setClearColor(0x080b14,0);
  renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.15;
  host.appendChild(renderer.domElement);
  const scene=new THREE.Scene(); scene.fog=new THREE.FogExp2(0x080b14,.015);
  const camera=new THREE.PerspectiveCamera(39,1,.1,180);
  const controls=new OrbitControls(camera,renderer.domElement); controls.enableDamping=true; controls.minDistance=7;controls.maxDistance=65;controls.maxPolarAngle=Math.PI*.48;controls.target.set(0,-.3,0);
  const composer=new EffectComposer(renderer);composer.addPass(new RenderPass(scene,camera));
  const bloom=new UnrealBloomPass(new THREE.Vector2(1,1),.55,.6,.85);composer.addPass(bloom);composer.addPass(new OutputPass());
  scene.add(new THREE.HemisphereLight(0xb7cce9,0x24102f,2.1));
  const key=new THREE.DirectionalLight(0xd6eeff,3);key.position.set(-8,18,10);scene.add(key);
  const rimLight=new THREE.DirectionalLight(0xad79ff,2.5);rimLight.position.set(5,2,-12);scene.add(rimLight);
  const under=new THREE.PointLight(0x934cff,70,35,2);under.position.set(0,-5,0);scene.add(under);
  const root=new THREE.Group();scene.add(root);
  // A sky dome adds depth without a downloaded backdrop or a screen-space overlay.
  const sky=new THREE.Mesh(new THREE.SphereGeometry(78,32,16),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,
    vertexShader:`varying vec3 vP;void main(){vP=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
    fragmentShader:`varying vec3 vP;
      float hash(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
      float noise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}
      void main(){vec3 p=normalize(vP);float n=noise(p*5.)*.55+noise(p*13.)*.3+noise(p*31.)*.15;float band=exp(-pow((p.y+.17+p.x*.23)*4.,2.));vec3 col=vec3(.014,.022,.043)+mix(vec3(.025,.09,.14),vec3(.19,.065,.24),smoothstep(-.8,.8,p.x))*pow(n,2.)*band;gl_FragColor=vec4(col,1.);}`,
    toneMapped:false}));scene.add(sky);
  const mistCanvas=document.createElement('canvas');mistCanvas.width=mistCanvas.height=256;
  const mc=mistCanvas.getContext('2d'),mg=mc.createRadialGradient(128,128,8,128,128,128);mg.addColorStop(0,'#7a30b988');mg.addColorStop(.42,'#773bd54d');mg.addColorStop(.72,'#3e328529');mg.addColorStop(1,'#281d5500');mc.fillStyle=mg;mc.fillRect(0,0,256,256);
  const mist=new THREE.Mesh(new THREE.PlaneGeometry(44,44).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(mistCanvas),transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,toneMapped:false}));mist.position.y=-4.8;scene.add(mist);
  // Procedural stone grain stays local and repeats at the physical tile scale.
  const texCanvas=document.createElement('canvas');texCanvas.width=texCanvas.height=128;const ctx=texCanvas.getContext('2d');
  ctx.fillStyle='#7e8796';ctx.fillRect(0,0,128,128);
  for(let i=0;i<5000;i++){const v=90+hash(i+16)*85;ctx.fillStyle=`rgba(${v},${v},${v},.23)`;ctx.fillRect(hash(i)*128,hash(i+9)*128,1+hash(i+2)*3,1);}
  const stone=new THREE.CanvasTexture(texCanvas);stone.colorSpace=THREE.SRGBColorSpace;stone.wrapS=stone.wrapT=THREE.RepeatWrapping;
  const rockMat=new THREE.MeshStandardMaterial({color:0x293341,roughness:.91,flatShading:true});
  const slabGeo=new THREE.ExtrudeGeometry(shape(1.065),{depth:.62,bevelEnabled:true,bevelSegments:1,steps:1,bevelSize:.045,bevelThickness:.035}).rotateX(-Math.PI/2);
  const tiles=new Map(), bursts=[], pits=new Map();
  // One atlas for all tile labels, so enabling the map does not allocate 111 textures.
  const atlas=document.createElement('canvas');atlas.width=atlas.height=1024;const ac=atlas.getContext('2d');ac.font='500 35px monospace';ac.textAlign='center';ac.textBaseline='middle';ac.fillStyle='#a8bfd0';
  ALL_HEXES.forEach((h,i)=>ac.fillText(h.num,(i%12)*80+40,Math.floor(i/12)*80+40));
  const numberTexture=new THREE.CanvasTexture(atlas);numberTexture.colorSpace=THREE.SRGBColorSpace;
  const numberMat=new THREE.MeshBasicMaterial({map:numberTexture,transparent:true,depthWrite:false,opacity:.7});
  ALL_HEXES.forEach((h,i)=>{
    const p=world(h.num), g=new THREE.Group();g.position.set(p.x,0,p.z);root.add(g);
    const mat=new THREE.MeshStandardMaterial({color:homes.get(h.num)??new THREE.Color().setHSL(.60,.12,.22+hash(h.num)*.055),map:stone,bumpMap:stone,bumpScale:.055,metalness:.48,roughness:.62});
    if(homes.has(h.num)){mat.color.multiplyScalar(.45);mat.emissive=new THREE.Color(homes.get(h.num));mat.emissiveIntensity=.08;}
    const slab=new THREE.Mesh(slabGeo,mat);slab.position.y=-.48;g.add(slab);
    const border=lineHex(1.064,.185,homes.get(h.num)??0x536b85,homes.has(h.num)?1:.62);g.add(border);
    const inset=lineHex(.88,.192,homes.get(h.num)??0x456078,homes.has(h.num)?.6:.18);g.add(inset);
    const seams=[];
    for(let j=0;j<3;j++){const a=j*Math.PI*2/3,r=.99;seams.push(new THREE.Vector3(Math.cos(a)*r,.2,Math.sin(a)*r),new THREE.Vector3(Math.cos(a)*.89,.2,Math.sin(a)*.89));}
    g.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(seams),new THREE.LineBasicMaterial({color:0xa8bdc9,transparent:true,opacity:.32})));
    const rock=new THREE.Mesh(new THREE.ConeGeometry(.99,1.2+hash(h.num)*1.7,6,1),rockMat);rock.rotation.z=Math.PI;rock.rotation.y=Math.PI/6;rock.position.y=-1.1;g.add(rock);
    const ng=new THREE.PlaneGeometry(.55,.55).rotateX(-Math.PI/2),uv=ng.attributes.uv;
    for(let j=0;j<uv.count;j++)uv.setXY(j,((i%12)*80+uv.getX(j)*80)/1024,1-(Math.floor(i/12)*80+(1-uv.getY(j))*80)/1024);
    const number=new THREE.Mesh(ng,numberMat);number.position.y=.199;g.add(number);
    if(homes.has(h.num)){
      const beacon=new THREE.Mesh(new THREE.RingGeometry(.53,.58,6).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:homes.get(h.num),toneMapped:false,transparent:true,opacity:.7}));beacon.position.y=.21;g.add(beacon);
    }
    tiles.set(h.num,{g,number,slab,mat,base:mat.color.clone(),born:-99,open:false});
  });
  const starGeo=new THREE.BufferGeometry(),stars=[];
  for(let i=0;i<550;i++)stars.push((hash(i+21)-.5)*110,(hash(i+81)-.45)*65,(hash(i+111)-.5)*110);
  starGeo.setAttribute('position',new THREE.Float32BufferAttribute(stars,3));
  scene.add(new THREE.Points(starGeo,new THREE.PointsMaterial({color:0x9cacd2,size:.06,transparent:true,opacity:.55,sizeAttenuation:true})));
  const floaters=[];
  for(let i=0;i<24;i++){
    const a=i*2.4,r=15+hash(i)*11,s=.18+hash(i+10)*.7;
    const m=new THREE.Mesh(new THREE.IcosahedronGeometry(s,0),rockMat);m.position.set(Math.cos(a)*r,-3-hash(i+60)*7,Math.sin(a)*r);m.rotation.set(i,i*.7,i*.3);scene.add(m);floaters.push({m,y:m.position.y});
  }
  const actors=new Map();
  for(const [id,art,color] of [['wildaxe','cosmic_ronin','#73ccff'],['vera','Metalness_Monster','#ff966c']]){
    const st=createStandee({...SPIRIT_DEFS[art],color},{T:{...STANDEE,height:2.8}});scene.add(st.group);actors.set(id,st);
  }
  let settings=prefs, current=null, action=null, view='wide', aim=null, disposed=false,last=performance.now()/1000, clock=0, shake=0;
  const getFocus=()=>world(current?.stageFx?.lastAbyss?.hexNum??current?.stageFx?.crumbling?.hexes?.[0]??56);
  function setView(kind,snap=false){
    view=kind;const target=kind==='close'?getFocus():new THREE.Vector3(0,-.5,0);
    const distance=kind==='close'?Math.max(11,5/(Math.tan(camera.fov*Math.PI/360)*camera.aspect)):Math.max(36,13/(Math.tan(camera.fov*Math.PI/360)*camera.aspect)),angle=kind==='top'?1.49:THREE.MathUtils.degToRad(64-settings.tilt);
    const pos=target.clone().add(new THREE.Vector3(distance*.13,Math.sin(angle)*distance,Math.cos(angle)*distance));
    aim={pos,target};if(snap||settings.motion){camera.position.copy(pos);controls.target.copy(target);aim=null;}controls.update();
  }
  controls.addEventListener('start',()=>{aim=null;});
  function pit(n){
    const g=new THREE.Group(),p=world(n);g.position.set(p.x,0,p.z);root.add(g);
    // Jagged stone collar surrounds an actual empty shaft; nothing caps the opening.
    const collar=shape(1.105,n,true),cut=shape(.77,n+50,true);collar.holes.push(new THREE.Path(cut.getPoints()));
    const collarMesh=new THREE.Mesh(new THREE.ExtrudeGeometry(collar,{depth:.38,bevelEnabled:false}).rotateX(-Math.PI/2),rockMat);collarMesh.position.y=-.23;g.add(collarMesh);
    const glow=new THREE.LineBasicMaterial({color:new THREE.Color(1.7,.7,3),toneMapped:false,transparent:true,opacity:.85});
    const rims=[];
    for(let j=0;j<4;j++){const l=lineHex(.84-j*.07,-j*.63,0xb887ff,.7-j*.14);g.add(l);rims.push(l);}
    const shaft=new THREE.Mesh(new THREE.CylinderGeometry(.85,.55,4.6,6,1,true),new THREE.ShaderMaterial({side:THREE.DoubleSide,
      vertexShader:`varying vec3 vP;void main(){vP=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
      fragmentShader:`varying vec3 vP;void main(){float d=clamp((vP.y+2.3)/4.6,0.,1.);float veins=pow(.5+.5*sin(atan(vP.z,vP.x)*21.+vP.y*2.),12.);vec3 col=mix(vec3(.002,.001,.006),vec3(.045,.014,.085),d*d)+vec3(.10,.025,.2)*veins*d*d;gl_FragColor=vec4(col,1.);}`,
      toneMapped:false}));shaft.rotation.y=Math.PI/6;shaft.position.y=-2.4;g.add(shaft);
    const black=new THREE.Mesh(new THREE.CircleGeometry(.6,6).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:0x020106}));black.position.y=-4.7;g.add(black);
    const cracks=[];
    for(let i=0;i<6;i++){
      const a=i*Math.PI/3+.1,pts=[new THREE.Vector3(Math.cos(a)*.76,.205,Math.sin(a)*.76),new THREE.Vector3(Math.cos(a+.07)*.94,.213,Math.sin(a+.07)*.94),new THREE.Vector3(Math.cos(a-.1)*1.06,.212,Math.sin(a-.1)*1.06)];
      const crack=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),glow);g.add(crack);cracks.push(crack);
    }
    // Broken facets interrupt the collar silhouette so it reads as torn rock.
    for(let j=0;j<9;j++){const a=j*Math.PI*2/9,shard=new THREE.Mesh(new THREE.TetrahedronGeometry(.13+hash(n+j)*.13),rockMat);shard.position.set(Math.cos(a)*.9,.11,Math.sin(a)*.9);shard.rotation.set(j,n,j*.7);g.add(shard);}
    const dustGeo=new THREE.BufferGeometry();dustGeo.setAttribute('position',new THREE.Float32BufferAttribute(new Float32Array(60),3));
    const dust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:new THREE.Color(1.4,.7,2.6),size:.045,transparent:true,opacity:.8,depthWrite:false,toneMapped:false}));g.add(dust);
    pits.set(n,{g,rims,glow,dust,born:clock});
  }
  const chunkGeo=new THREE.IcosahedronGeometry(.14,0);
  const chunkMat=new THREE.MeshStandardMaterial({color:0x7a6b94,roughness:.9,flatShading:true});
  function burst(n,count=20){
    const p=world(n);
    for(let i=0;i<count;i++){
      const m=new THREE.Mesh(chunkGeo,chunkMat),a=hash(i+n)*Math.PI*2,r=.45+hash(i+n+9)*.45;m.position.copy(p).add(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r));m.scale.set(.5+hash(i)*1.4,.4+hash(i+7)*1.8,.7);scene.add(m);
      bursts.push({m,origin:m.position.clone(),vx:Math.cos(a)*(.2+hash(i+21)*.5),vz:Math.sin(a)*(.2+hash(i+21)*.5),start:clock+hash(i+n)*.16,life:1.4+hash(i)*.7});
    }
  }
  function removePit(p){root.remove(p.g);p.g.traverse(o=>{o.geometry?.dispose();if(o.material&&o.material!==rockMat){o.material.dispose();}});}
  function sync(state,event={}){
    current=state;
    const holes=new Set(state.stageFx.crumbling?.hexes??[]);
    if(event.kind==='reset'){action=null;for(const b of bursts)scene.remove(b.m);bursts.length=0;shake=0;}
    for(const [n,t]of tiles){
      const open=holes.has(n);
      if(open&&!t.open){pit(n);t.born=clock;if(!settings.motion)burst(n,Math.round(settings.debris*.32));shake=settings.motion?0:settings.shake*.02;}
      if(!open&&pits.has(n)){removePit(pits.get(n));pits.delete(n);}
      t.open=open;t.g.position.y=0;t.g.rotation.set(0,0,0);t.g.scale.setScalar(1);t.g.visible=!open||(!settings.motion&&clock-t.born<1.2);
    }
    for(const s of state.spirits){const st=actors.get(s.id);st.group.visible=Number.isFinite(s.num);if(st.group.visible){st.group.position.copy(world(s.num));st.group.rotation.set(0,.12,0);st.group.scale.setScalar(1);}}
    if(event.kind==='fall'){
      const st=actors.get('vera');st.group.visible=true;action={kind:'fall',start:clock,from:world(event.from),to:world(event.to),duration:.45+settings.speed/1000};
      if(!settings.motion)burst(event.to,Math.round(settings.debris*.45));
    }
    if(event.kind==='return')action={kind:'return',start:clock,to:world(state.spirits.find(s=>s.id==='vera').num),duration:.8};
    if(view==='close')setView('close');
  }
  function configure(p){const old=settings;settings={...p};bloom.strength=p.bloom/100;for(const t of tiles.values())t.number.visible=p.numbers;if(old.tilt!==p.tilt)setView(view);}
  function resize(){const w=host.clientWidth,h=host.clientHeight;renderer.setSize(w,h,false);composer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();if(view==='wide')setView(view);}
  const observer=new ResizeObserver(resize);observer.observe(host);setView('wide',true);configure(prefs);
  function frame(now){
    if(disposed)return;const dt=Math.min(.05,now/1000-last);last=now/1000;if(!document.hidden)clock+=dt;
    if(aim){const k=settings.motion?1:1-Math.exp(-dt*5);camera.position.lerp(aim.pos,k);controls.target.lerp(aim.target,k);if(camera.position.distanceTo(aim.pos)<.01)aim=null;}
    controls.update();
    for(const t of tiles.values())if(t.open){const age=clock-t.born;t.g.visible=!settings.motion&&age<1.2;if(t.g.visible){const k=clamp((age-.15)/1,0,1);t.g.position.y=-6*k*k;t.g.rotation.x=k*.4;t.g.rotation.z=k*.3;t.g.scale.setScalar(1-k*.65);}}
    for(const p of pits.values()){const pulse=settings.motion?1:.92+.08*Math.sin(clock*2.7+p.born);p.rims.forEach((l,i)=>{l.material.opacity=(settings.rim/100)*(.95-i*.18)*pulse;l.material.color.setRGB(1.4,.65,2.8);});p.glow.opacity=settings.rim/100;
      const pos=p.dust.geometry.attributes.position,t=settings.motion?0:clock;
      for(let i=0;i<20;i++){const a=i*2.399+t*.3,r=.35+hash(i)*.28;pos.setXYZ(i,Math.cos(a)*r,.65-((i*.23+t*.55)%4),Math.sin(a)*r);}pos.needsUpdate=true;p.dust.visible=settings.debris>0;p.dust.material.opacity=settings.debris/100;
    }
    for(let i=bursts.length-1;i>=0;i--){const b=bursts[i],t=clock-b.start;if(t>b.life||settings.motion){scene.remove(b.m);bursts.splice(i,1);continue;}b.m.visible=t>=0;if(t>=0){b.m.position.copy(b.origin).add(new THREE.Vector3(b.vx*t,.4*t-4.5*t*t,b.vz*t));b.m.rotation.set(t*2,t*3,t);b.m.scale.setScalar(Math.max(.02,1-t/b.life));}}
    for(const f of floaters){f.m.position.y=f.y+(settings.motion?0:Math.sin(clock*.3+f.y)*.22);}
    for(const st of actors.values())st.frame(clock,{cameraPos:camera.position,reduced:settings.motion});
    if(action){
      const a=action,age=clock-a.start,t=clamp(age/a.duration,0,1),st=actors.get('vera');st.group.visible=true;
      if(a.kind==='fall'){
        const move=clamp(age/.45,0,1);st.group.position.copy(a.from).lerp(a.to,move*move*(3-2*move));
        const fall=clamp((age-.45)/(a.duration-.45),0,1);
        st.group.position.y=.2-8*fall*fall;st.group.scale.setScalar(1-fall*.87);st.group.rotation.set(fall*.7,.12+fall*3,fall*.6);
        if(settings.motion)st.group.visible=false;
      }else{st.group.position.copy(a.to);st.group.position.y+=settings.motion?0:(1-t)*3;st.group.scale.setScalar(settings.motion?1:.4+.6*t);st.group.rotation.set(0,.12,0);}
      if(t>=1){st.group.visible=a.kind==='return';st.group.scale.setScalar(1);st.group.rotation.set(0,.12,0);action=null;onSettled?.();}
    }
    const dx=settings.motion?0:Math.sin(clock*77)*shake;camera.position.x+=dx;composer.render();camera.position.x-=dx;shake*=Math.exp(-dt*5);
  }
  renderer.setAnimationLoop(frame);
  renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();renderer.setAnimationLoop(null);host.insertAdjacentHTML('beforeend','<div class="error">The graphics context was interrupted.<br>Reload this page to restore the stage.</div>');});
  return {sync,configure,setView,dispose(){disposed=true;renderer.setAnimationLoop(null);observer.disconnect();controls.dispose();const geometries=new Set(),materials=new Set(),textures=new Set();scene.traverse(o=>{if(o.geometry)geometries.add(o.geometry);for(const m of(o.material?(Array.isArray(o.material)?o.material:[o.material]):[])){materials.add(m);for(const v of Object.values(m))if(v?.isTexture)textures.add(v);}});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());composer.dispose();renderer.dispose();}};
}
