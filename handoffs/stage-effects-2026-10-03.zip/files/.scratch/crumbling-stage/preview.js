import { HEX_BY_NUM } from '../../src/board/hexMap.js';
import { straightNeighborInDirection } from '../../src/board/hexGeometry.js';
import { makeInitialState } from '../../src/engine/state.js';
import { applyAction } from '../../src/engine/reduce.js';
import { stageFxActivated, stageFxRoundTicked, turnStarted, spiritsSynced } from '../../src/engine/actions.js';
import { knockback, runBattleFlow } from '../../src/engine/systems/battleFlow.js';
import { createStage } from './stage.js';

const $=id=>document.getElementById(id);
const levers=[['rim','Abyss glow',0,100,1,'%'],['bloom','Bloom',0,120,5,'%'],['debris','Falling debris',0,100,5,'%'],['speed','Fall duration',300,2000,50,'ms'],['tilt','Camera tilt',0,45,1,'°'],['shake','Collapse shake',0,100,5,'%']];
const defaults={rim:75,bloom:55,debris:65,speed:950,tilt:22,shake:35,seed:31,numbers:false,motion:matchMedia('(prefers-reduced-motion: reduce)').matches};
const storageKey='rlsw-crumbling-stage-v2';
let prefs={...defaults};
try{
  const stored=JSON.parse(localStorage.getItem(storageKey)??localStorage.getItem('rlsw-crumbling-stage-v1')??'{}');
  for(const [key,,min,max]of levers)if(Number.isFinite(stored[key]))prefs[key]=Math.min(max,Math.max(min,stored[key]));
  if(Number.isFinite(stored.seed))prefs.seed=Math.min(99999,Math.max(1,Math.floor(stored.seed)));
  for(const key of ['numbers','motion'])if(typeof stored[key]==='boolean')prefs[key]=stored[key];
}catch{/* Private storage must not disable the preview. */}
$('levers').innerHTML=levers.map(([key,label,min,max,step])=>`<div class="lever"><label for="${key}">${label}<output id="${key}v"></output></label><input id="${key}" type="range" min="${min}" max="${max}" step="${step}"></div>`).join('');
let state,logs=[],stage=null,busy=false,busyTimer=0,cueTimer=0,loss=0;
function cue(text){clearTimeout(cueTimer);$('cue').textContent=text;$('cue').classList.add('visible');cueTimer=setTimeout(()=>$('cue').classList.remove('visible'),1900);}
function settle(){busy=false;render();}
function hold(ms){clearTimeout(busyTimer);busy=true;busyTimer=setTimeout(settle,ms);}
function dispatch(action){state=applyAction(state,action);}
function lane(){
  const holes=state.stageFx.crumbling?.hexes??[];
  for(const n of holes)for(const angle of [0,60,120,180,240,300]){
    const hole=HEX_BY_NUM[n],target=straightNeighborInDirection(hole,angle+180),attacker=target&&straightNeighborInDirection(target,angle+180);
    if(attacker&&target&&!holes.includes(target.num)&&!holes.includes(attacker.num))return{hole,target,attacker,angle};
  }return null;
}
function render(){
  try{localStorage.setItem(storageKey,JSON.stringify(prefs));}catch{/* Controls remain usable without storage. */}
  for(const [key,,, , ,unit]of levers){$(key).value=prefs[key];$(key+'v').textContent=`${prefs[key]}${unit}`;}
  $('seed').value=prefs.seed;for(const key of ['numbers','motion'])$(key).checked=prefs[key];
  const show=state.stageFx.crumbling,holes=show?.hexes??[],victim=state.spirits.find(s=>s.id==='vera');
  $('showtag').textContent=show?'CRUMBLING STAGE / ACTIVE':'INTACT STAGE';
  $('roundtag').textContent=show?`SHOW ROUND ${show.showRound} / 3 · ${show.roundsLeft} LEFT`:'111 HEXES / 4 PROTECTED HOMES';
  $('holes').textContent=String(holes.length).padStart(2,'0');$('fp').textContent=state.noteStates.vera.fame;
  $('loss').textContent=loss?`−${loss} FP on last fall`:'No FP lost';
  $('status').textContent=victim.abyssPending?'In the abyss':victim.num===105?'Home · hex 105':`On stage · hex ${victim.num}`;
  $('status').classList.toggle('pending',!!victim.abyssPending);
  $('vibe').textContent=victim.abyssPending?'Returns on own next turn':`Vibe ${victim.vibe}/${victim.maxVibe} · lives intact`;
  $('instruction').textContent=victim.abyssPending?'An empty spotlight. A way back next turn.':show?'The gaps stay open. Line up the shove.':'Open four traps. Find your next opening.';
  $('log').textContent=logs.slice(-2).join(' ');
  $('push').disabled=busy||!lane()||!!victim.abyssPending;$('turn').disabled=busy||!victim.abyssPending;$('round').disabled=busy||!holes.length;$('start').disabled=busy||!!show;
  stage?.configure(prefs);
}
function reset(){
  clearTimeout(busyTimer);clearTimeout(cueTimer);busy=false;loss=0;$('cue').classList.remove('visible');
  const fame=Math.min(999,Math.max(0,Math.floor(Number($('fame').value)||0)));$('fame').value=fame;
  state=makeInitialState({spirits:[{id:'wildaxe',name:'Wildaxe',num:7,corner:'blue',facing:0,vibe:10,maxVibe:10},{id:'vera',name:'Vera',num:105,corner:'red',facing:3,vibe:10,maxVibe:10}],mode:'ffa',startingLives:3},prefs.seed);
  state.noteStates.vera.fame=fame;logs=['The stage is intact. Crumble it to reveal the traps.'];stage?.sync(state,{kind:'reset'});render();
}
$('start').onclick=()=>{dispatch(stageFxActivated('crumbling_stage',[],3));hold(prefs.motion?100:1300);stage?.sync(state);logs.push('Four empty hexes fracture and fall away. Home hexes stay safe.');cue('THE FLOOR GIVES WAY');render();};
$('round').onclick=()=>{dispatch(stageFxRoundTicked());hold(prefs.motion?100:1300);stage?.sync(state);logs.push(state.stageFx.crumbling?'Four more hexes collapse. The earlier holes stay open.':'The show ends. The stage reforms; fallen Spirits still return on their own turns.');cue(state.stageFx.crumbling?'FOUR MORE FALL':'THE STAGE REFORMS');render();};
$('push').onclick=()=>{
  const l=lane();if(!l||busy)return;
  dispatch(spiritsSynced(state.spirits.map(s=>({...s,num:s.id==='vera'?l.target.num:l.attacker.num}))));
  state=runBattleFlow(knockback({state,fromId:'wildaxe',targetId:'vera',spaces:3,direction:l.angle}),state,{applyAction}).state;
  const report=state.stageFx.lastAbyss;loss=report?.lost??0;
  hold(450+prefs.speed+100);stage?.sync(state,{kind:'fall',from:l.target.num,to:report?.hexNum??l.hole.num});
  logs.push(`Vera is shoved into #${report?.hexNum}. −${loss} FP (10%, rounded up). The shove stops at the hole.`);cue(`INTO THE ABYSS / −${loss} FP`);render();
};
$('turn').onclick=()=>{dispatch(turnStarted('vera'));hold(850);stage?.sync(state,{kind:'return'});logs.push('Vera’s own turn: back at #105 with full Vibe. No life lost.');cue('BACK FOR THE ENCORE');render();};
$('reset').onclick=reset;$('fame').onchange=reset;
for(const [key]of levers)$(key).oninput=()=>{prefs[key]=Number($(key).value);render();};
$('seed').onchange=()=>{prefs.seed=Math.min(99999,Math.max(1,Math.floor(Number($('seed').value)||31)));reset();};
for(const key of ['numbers','motion'])$(key).onchange=()=>{prefs[key]=$(key).checked;render();};
$('defaults').onclick=()=>{prefs={...defaults,seed:prefs.seed};render();};
for(const id of ['wide','close','top'])$(id).onclick=()=>{stage?.setView(id);for(const other of ['wide','close','top'])$(other).classList.toggle('active',other===id);};
$('copy').onclick=async()=>{
  const data={preview:'Crumbling Stage / 3D',settings:Object.fromEntries(Object.keys(defaults).map(k=>[k,{value:prefs[k],default:defaults[k],changed:prefs[k]!==defaults[k]}])),rules:{fpLoss:'10%, rounded up',respawn:'next own turn, home hex, full Vibe',holesPerRound:4,duration:3,lives:'unchanged'}};
  $('dial').classList.add('revealed');$('dial').value=JSON.stringify(data,null,2);$('dial').select();
  try{await navigator.clipboard.writeText($('dial').value);$('copystatus').textContent='Copied. Paste these settings into the chat.';}catch{$('copystatus').textContent='Settings selected. Press Ctrl+C to copy.';}
};
reset();
try{stage=createStage($('board'),prefs,settle);stage.sync(state);render();}
catch(error){console.error(error);$('board').innerHTML='<div class="error">The 3D stage needs WebGL.<br><a href="./original.html">Open the original 2D study ↗</a></div>';}
window.addEventListener('pagehide',()=>{stage?.dispose();clearTimeout(busyTimer);clearTimeout(cueTimer);});
