import { ALL_HEXES, HEX_BY_NUM } from '../../src/board/hexMap.js';
import { straightNeighborInDirection } from '../../src/board/hexGeometry.js';
import { makeInitialState } from '../../src/engine/state.js';
import { applyAction } from '../../src/engine/reduce.js';
import { stageFxActivated, stageFxRoundTicked, turnStarted, spiritsSynced } from '../../src/engine/actions.js';
import { knockback, runBattleFlow } from '../../src/engine/systems/battleFlow.js';

const $ = id => document.getElementById(id);
const defaults = { rim: 55, speed: 950, tilt: 22, seed: 31 };
const storageKey = 'rlsw-crumbling-stage-v1';
let prefs = { ...defaults };
try { prefs = { ...defaults, ...JSON.parse(localStorage.getItem(storageKey) ?? '{}') }; } catch { /* storage can be unavailable */ }
for (const key of Object.keys(defaults)) $(key).value = prefs[key];
let state, logs = [], fallen = null;
function reset() {
  state = makeInitialState({ spirits: [
    { id: 'wildaxe', name: 'Wildaxe', num: 7, corner: 'blue', facing: 0, vibe: 10, maxVibe: 10 },
    { id: 'vera', name: 'Vera', num: 105, corner: 'red', facing: 3, vibe: 10, maxVibe: 10 },
  ], mode: 'ffa', startingLives: 3 }, prefs.seed);
  state.noteStates.vera.fame = Math.max(0, Number($('fame').value) || 0);
  fallen = null; logs = ['The stage is intact. Crumble it to reveal the traps.']; render();
}
function dispatch(action) { state = applyAction(state, action); }
function lane() {
  const holes = state.stageFx.crumbling?.hexes ?? [];
  for (const n of holes) for (const angle of [0, 60, 120, 180, 240, 300]) {
    const hole = HEX_BY_NUM[n], target = straightNeighborInDirection(hole, angle + 180);
    const attacker = target && straightNeighborInDirection(target, angle + 180);
    if (attacker && target && !holes.includes(target.num) && !holes.includes(attacker.num)) return { hole, target, attacker, angle };
  }
  return null;
}
function render() {
  try { localStorage.setItem(storageKey, JSON.stringify(prefs)); } catch { /* controls still work */ }
  document.documentElement.style.setProperty('--tilt', `${prefs.tilt}deg`);
  document.documentElement.style.setProperty('--speed', `${prefs.speed}ms`);
  document.documentElement.style.setProperty('--rim', `hsl(268 60% ${15 + prefs.rim * .55}%)`);
  $('rimv').textContent = `${prefs.rim}%`; $('speedv').textContent = `${prefs.speed}ms`; $('tiltv').textContent = `${prefs.tilt}°`;
  const holes = state.stageFx.crumbling?.hexes ?? [], victim = state.spirits.find(s => s.id === 'vera');
  const points = (h, size = 191) => Array.from({ length: 6 }, (_, i) => {
    const a = i * Math.PI / 3; return `${h.px + Math.cos(a) * size},${h.py + Math.sin(a) * size}`;
  }).join(' ');
  const pieces = ALL_HEXES.map(h => `<g class="${holes.includes(h.num) ? 'hole' : [7,12,100,105].includes(h.num) ? 'home' : ''}"><polygon points="${points(h)}"/><text class="tiletext" x="${h.px}" y="${h.py+12}">${h.num}</text>${holes.includes(h.num) ? `<path class="crack" d="M${h.px-185},${h.py} l40,20 -20,35 M${h.px+90},${h.py-155} l-10,40 35,12"/><polygon class="shard" points="${h.px-75},${h.py-20} ${h.px-20},${h.py-40} ${h.px-38},${h.py+20}"/>` : ''}</g>`).join('');
  const spirit = (sp, num = sp.num, extra = '') => {
    const h = HEX_BY_NUM[num]; if (!h) return '';
    return `<g class="spirit ${sp.id==='vera'?'victim':''} ${extra}"><circle cx="${h.px}" cy="${h.py-35}" r="72"/><text x="${h.px}" y="${h.py-25}">${sp.id==='vera'?'V':'W'}</text></g>`;
  };
  $('board').innerHTML = `<svg viewBox="1050 400 4400 3850" role="img" aria-label="111-hex stage with ${holes.length} abyss holes">${pieces}${state.spirits.map(s=>spirit(s)).join('')}${fallen ? spirit(victim, fallen, 'falling') : ''}</svg>`;
  $('showtag').textContent = state.stageFx.crumbling ? `CRUMBLING STAGE · SHOW ROUND ${state.stageFx.crumbling.showRound} · ${state.stageFx.crumbling.roundsLeft} LEFT` : 'INTACT STAGE · 111 HEXES';
  $('holes').textContent = holes.length; $('fp').textContent = state.noteStates.vera.fame;
  $('status').textContent = victim.abyssPending ? 'In the abyss · returns next turn' : victim.num === 105 ? 'At starting hex #105' : `On hex #${victim.num}`;
  $('log').textContent = logs.slice(-3).join(' ');
  $('push').disabled = !lane() || !!victim.abyssPending;
  $('turn').disabled = !victim.abyssPending; $('round').disabled = !holes.length;
  $('start').disabled = !!state.stageFx.crumbling;
}
$('start').onclick = () => { dispatch(stageFxActivated('crumbling_stage', [], 3)); logs.push('Four empty hexes collapse. The dark pits are now KO traps.'); render(); };
$('round').onclick = () => { dispatch(stageFxRoundTicked()); logs.push(state.stageFx.crumbling ? 'Four more empty hexes give way; earlier holes stay open.' : 'The show ends and the stage repairs. A fallen Spirit still returns on its own next turn.'); render(); };
$('push').onclick = () => {
  const l = lane(); if (!l) return;
  dispatch(spiritsSynced(state.spirits.map(s => ({ ...s, num: s.id==='vera' ? l.target.num : l.attacker.num }))));
  const out = runBattleFlow(knockback({ state, fromId:'wildaxe', targetId:'vera', spaces:3, direction:l.angle }), state, { applyAction });
  state = out.state; const report = state.stageFx.lastAbyss;
  fallen = report?.hexNum; logs.push(`Vera is shoved into #${fallen}. −${report?.lost} FP (10%, rounded up). The shove ends immediately.`); render();
};
$('turn').onclick = () => { dispatch(turnStarted('vera')); fallen = null; logs.push('Vera’s own next turn: back at #105, full Vibe, ready to play.'); render(); };
$('reset').onclick = reset;
for (const key of Object.keys(defaults)) $(key).oninput = () => { prefs[key] = Number($(key).value); if (key==='seed') reset(); else render(); };
$('fame').onchange = reset;
$('copy').onclick = async () => {
  const data = { preview:'Crumbling Stage', settings:Object.fromEntries(Object.keys(defaults).map(k => [k,{ value:prefs[k], default:defaults[k], changed:prefs[k]!==defaults[k] }])), rules:{ fpLoss:'10%, rounded up', respawn:'next own turn, starting hex, full Vibe', holesPerRound:4, duration:3, lives:'unchanged' } };
  $('dial').value = JSON.stringify(data, null, 2); $('dial').select();
  try { await navigator.clipboard.writeText($('dial').value); $('copystatus').textContent='Copied — paste this into the chat.'; } catch { $('copystatus').textContent='Select and copy the text above.'; }
};
reset();
