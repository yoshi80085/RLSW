# Crumbling Stage — graphics study

Open `/RLSW/.scratch/crumbling-stage/index.html` on the local Vite server.
Start it from the repository root with `node node_modules/vite/bin/vite.js --host 127.0.0.1`.

The original 2D study is preserved at `original.html` (linked from the page).
This is a preview-only graphics pass; the live client and game rules were not edited.

## What is here

- `preview.js`: original real-engine scenario, controls, validation, persistence, and dial-in export.
- `stage.js`: persistent Three.js scene, stone-and-metal slabs, fractured collars and deep shafts,
  procedural nebula, falling rubble and motes, acrylic standees, shove/fall/return choreography,
  three camera presets, orbit/zoom, bloom, reduced motion, and resource cleanup.
- `style.css`: desktop lab layout with a stacked arrangement for narrow desktop preview panes.

The preview uses the shipped standee renderer and existing Ronin/Monster artwork to represent
its original Wildaxe/Vera test fixtures. It uses the existing hex map and reducers for all rules.
All new environment art is procedural and local; only the optional Google Fonts stylesheet
requires a network request, with system-font fallbacks.

Visual controls save in `rlsw-crumbling-stage-v2`, migrating the prior preview's numerical
settings when available. Copy dial-in shows selectable JSON first and marks each setting's
changed/default status. Changing seed or starting Fame resets the scenario. Reset preserves
art direction; Restore look preserves the pattern seed.

## Verification — 2026-10-03

- Preview JavaScript syntax and in-memory bundle: passed, zero bundler warnings.
- Crumbling engine suite: 344 assertions passed.
- Browser: WebGL renders, no console errors/warnings; 4 → 8 → 12 → 0 holes; push changes
  Fame 23 → 20 and removes the rival; next own turn returns it to #105 at 10/10 Vibe.
- Browser: camera presets, settings export (changed glow marked true), and reload persistence.
- Full repository suite passes vocab (640), cards (441), card journey (14), marquee markers (50),
  marquee journey (14), then stops at the existing `src/engine/selftest.mjs:457` assertion
  `atkTotal = stat + roll` (actual 4, expected 11), also recorded in STATE_OF_PLAY.md.

Use Crumble stage, Hazard close-up, then Push rival into abyss to inspect the choreography.
The art is ready for dialing in; porting this renderer into the live arena is a separate step.
