# Bat Stage Effect — Night Flight

Standalone visual study, 2026-10-03. Run the repository's Vite server and open
`/RLSW/.scratch/stage-bats/`. No live game modules are changed by this study.

Uses the actual Cosmic Arena GLB, arena lighting and Ronin standee. New procedural
3D bats have wine-red scalloped membranes, two-part wings, curved finger bones,
obsidian bodies, inner ears, fangs and luminous eyes. Four occupied-hex markers
remain pinned underneath the hovering models. Current bat comparison imports
the actual `src/board/batStage.js` into a separate inspection window.

The 18-second film offers entrance, stalking/sonar, bite/recoil, catch/reward and
spiral-exit moments. Bite and catch use the current damage and fan constants.
It is staged choreography, not a rules simulator: the real 30-second steps and
target priorities are described on the page. A production port must consume
`stageFx.lastBats.hits/eaten/moves` and drive markers from the engine's bat hexes.
No extra roosting rule is implemented. Audio is not included in this visual pass.

**Alex's instruction, 2026-10-03: keep BOTH bat assets.** He likes the charm of
Sol 6.1's original bat. Preserve `src/board/batStage.js` alongside this folder's
`batShow.js`; do not replace or delete the original on integration. The original
remains live and is available in the comparison window. A later integration
should keep both as selectable styles.

Seven sliders, three presets, camera choices, layer toggles, reduced motion,
pause, seek, half-speed, current-model comparison and copyable JSON dial-in.
Settings persist by page path; export explicitly distinguishes changed settings
from untouched defaults. System reduced motion starts paused with minimal poses.

Possible next gameplay idea: an amp roost, flushed by its owner's next melody.
This is a proposal only; balance and rule changes need a separate decision.
