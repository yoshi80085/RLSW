import * as THREE from 'three';

export const DEFAULTS = Object.freeze({size:1.1,flap:1,height:2.3,glow:1.1,bank:.65,particles:1,bloom:.5,entrance:true,sonar:true,shadows:true,compare:false,reduced:false,camera:'hero'});
export const SLIDERS = [['size','Wingspan',.65,1.6,.05],['flap','Wingbeat',.4,1.8,.05],['height','Hover height',1.5,3.5,.1],['glow','Vein glow',0,2,.05],['bank','Bank into turns',0,1,.05],['particles','Collision sparks',0,1.5,.1],['bloom','Bloom',0,1,.05]];
export const smooth = n => { const u=THREE.MathUtils.clamp(n,0,1);return u*u*(3-2*u); };

// Geometry, not a facing billboard: membranes and finger bones remain readable
// from the match camera as well as the close inspection camera.
export function makeBat() {
 const root=new THREE.Group(), wings=[];
 const skin=new THREE.MeshStandardMaterial({color:'#171422',roughness:.66,metalness:.18});
 const membrane=new THREE.MeshStandardMaterial({color:'#661c48',emissive:'#4b123e',emissiveIntensity:.35,roughness:.46,metalness:.12,side:THREE.DoubleSide});
 const ribs=new THREE.MeshStandardMaterial({color:'#a376bd',emissive:'#943dcc',emissiveIntensity:.5,roughness:.35});
 function orb(parent,material,scale,pos){const m=new THREE.Mesh(new THREE.SphereGeometry(1,16,12),material);m.scale.set(...scale);m.position.set(...pos);parent.add(m);return m;}
 orb(root,skin,[.18,.18,.38],[0,0,0]);orb(root,skin,[.21,.2,.2],[0,.07,.27]);
 function bone(parent,points,r=.014){const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));parent.add(new THREE.Mesh(new THREE.TubeGeometry(curve,12,r,5,false),ribs));}
 for(const side of [-1,1]){
  const shoulder=new THREE.Group();shoulder.position.x=side*.12;root.add(shoulder);
  const mirrored=new THREE.Group();mirrored.scale.x=side;shoulder.add(mirrored);
  const wrist=new THREE.Group();wrist.position.set(.47,.01,.19);mirrored.add(wrist);
  const arm=new THREE.Shape();arm.moveTo(0,.14);arm.quadraticCurveTo(.21,.4,.47,.19);arm.lineTo(.48,-.37);arm.quadraticCurveTo(.24,-.21,0,-.3);arm.closePath();
  mirrored.add(new THREE.Mesh(new THREE.ShapeGeometry(arm,16).rotateX(Math.PI/2),membrane));
  const shape=new THREE.Shape();shape.moveTo(0,0);shape.quadraticCurveTo(.4,.3,.93,.14);shape.quadraticCurveTo(.61,-.05,.72,-.46);shape.quadraticCurveTo(.39,-.16,.36,-.65);shape.quadraticCurveTo(.12,-.36,0,-.56);shape.closePath();
  wrist.add(new THREE.Mesh(new THREE.ShapeGeometry(shape,20).rotateX(Math.PI/2),membrane));
  bone(mirrored,[[0,.015,.14],[.23,.065,.34],[.47,.015,.19]],.025);
  for(const tip of [[.93,.01,.14],[.72,.01,-.46],[.36,.01,-.65],[0,.01,-.56]])bone(wrist,[[0,.025,0],[tip[0]*.6,.045,tip[2]*.45],tip]);
  const ear=new THREE.Mesh(new THREE.ConeGeometry(.1,.32,4),skin);ear.position.set(side*.135,.28,.22);ear.rotation.z=-side*.23;root.add(ear);
  const inner=new THREE.Mesh(new THREE.ConeGeometry(.053,.19,3),membrane);inner.position.set(side*.135,.29,.265);root.add(inner);
  const eye=orb(root,new THREE.MeshBasicMaterial({color:'#ff645c',toneMapped:false}),[.034,.026,.027],[side*.103,.13,.443]);eye.material.color.multiplyScalar(2.2);
  const fang=new THREE.Mesh(new THREE.ConeGeometry(.018,.075,5),new THREE.MeshStandardMaterial({color:'#ead8de'}));fang.rotation.x=Math.PI;fang.position.set(side*.055,-.05,.422);root.add(fang);
  wings.push({shoulder,wrist,side});
 }
 const tail=new THREE.Mesh(new THREE.ConeGeometry(.11,.3,3),membrane);tail.rotation.x=-Math.PI/2;tail.position.z=-.4;root.add(tail);
 return {root,pose(time,L,index=0){root.scale.setScalar(L.size);membrane.emissiveIntensity=.15+L.glow*.2;ribs.emissiveIntensity=L.glow;
  const beat=time*12*L.flap+index*1.91;
  for(const {shoulder,wrist,side} of wings){shoulder.rotation.z=L.reduced?side*.18:side*(.18+Math.sin(beat)*.53);wrist.rotation.z=L.reduced?0:Math.sin(beat-.7)*.28;}
 }};
}

export function makeMarker() {
 const root=new THREE.Group();
 const mat=new THREE.MeshBasicMaterial({color:'#bc8cff',transparent:true,opacity:.6,side:THREE.DoubleSide,depthWrite:false});
 const rim=new THREE.Mesh(new THREE.RingGeometry(.86,.9,6).rotateX(-Math.PI/2),mat);root.add(rim);
 const shadow=new THREE.Mesh(new THREE.CircleGeometry(.6,28).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:'#030108',transparent:true,opacity:.5,depthWrite:false}));shadow.position.y=-.007;root.add(shadow);
 return {root,shadow};
}

export function disposeTree(root){const geometries=new Set(),materials=new Set();root.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)for(const m of [o.material].flat())materials.add(m);});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());}
