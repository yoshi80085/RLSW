import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { createArenaEnvironment, polishArenaModel } from '../../src/board/arenaEnvironment.js';
import { createStandee } from '../../src/board/standee.js';
import { SPIRIT_DEFS } from '../../src/data/spirits.js';
import { HEX_BY_NUM } from '../../src/board/hexMap.js';
import { createBatStage } from '../../src/board/batStage.js';
import { BAT_DAMAGE, BAT_FAN_GAIN, BAT_STEP_MS } from '../../src/data/stageEffects.js';
import { DEFAULTS, SLIDERS, smooth, makeBat, makeMarker, disposeTree } from './batShow.js';

const $=id=>document.getElementById(id), storage=`rlsw.bats.look.v1:${location.pathname}`;
const media=matchMedia('(prefers-reduced-motion: reduce)');
let L={...DEFAULTS,reduced:media.matches};
try {const saved=JSON.parse(localStorage.getItem(storage)||'{}');for(const [k,,min,max] of SLIDERS)if(Number.isFinite(saved[k]))L[k]=THREE.MathUtils.clamp(saved[k],min,max);for(const k of ['entrance','sonar','shadows','compare','reduced'])if(typeof saved[k]==='boolean')L[k]=saved[k];if(['hero','board','top'].includes(saved.camera))L.camera=saved.camera;}catch{/* Browser persistence is optional. */}
if(media.matches)L.reduced=true;
let age=0,paused=media.matches,speed=1,ready=false,disposed=false;
const presetLooks={theatrical:{...DEFAULTS},restrained:{...DEFAULTS,size:.9,glow:.45,bank:.25,particles:.5,bloom:.25},supernatural:{...DEFAULTS,size:1.3,glow:1.8,bank:.9,particles:1.4,bloom:.75}};
for(const [key,label,min,max,step] of SLIDERS){const row=document.createElement('label');row.className='slider';row.innerHTML=`<span>${label}<output id="${key}Value"></output></span><input id="${key}" aria-label="${label}" type="range" min="${min}" max="${max}" step="${step}">`;$('sliders').append(row);$(key).oninput=()=>{L[key]=Number($(key).value);sync();};}
for(const [key,label] of [['entrance','Swarm entrance & exit'],['sonar','Echolocation rings'],['shadows','Ground shadows'],['compare','Compare current bat'],['reduced','Reduced motion']]){const row=document.createElement('label');row.innerHTML=`${label}<input type="checkbox" id="${key}">`;$('toggles').append(row);$(key).onchange=()=>{L[key]=$(key).checked;sync();};}
function sync(){
 for(const [key] of SLIDERS){$(key).value=L[key];$(`${key}Value`).textContent=`${L[key].toFixed(2)}${L[key]!==DEFAULTS[key]?' *':''}`;$(key).closest('label').classList.toggle('changed',L[key]!==DEFAULTS[key]);}
 for(const key of ['entrance','sonar','shadows','compare','reduced'])$(key).checked=L[key];$('camera').value=L.camera;
 $('comparison').hidden=!L.compare;
 for(const b of document.querySelectorAll('[data-preset]'))b.classList.toggle('selected',SLIDERS.every(([k])=>L[k]===presetLooks[b.dataset.preset][k]));
 $('dial').value=JSON.stringify({study:'Bat Stage Effect / Night Flight',version:1,settings:L,changed:Object.fromEntries(Object.entries(L).filter(([k,v])=>v!==DEFAULTS[k])),untouched:Object.keys(L).filter(k=>L[k]===DEFAULTS[k])},null,2);
 try{localStorage.setItem(storage,JSON.stringify(L));}catch{$('saved').textContent='Browser storage is unavailable. Copy your settings to keep them.';}
}
function pause(value){paused=value;$('play').textContent=paused?'Play':'Pause';}
$('play').onclick=()=>pause(!paused);$('replay').onclick=()=>{age=0;pause(false);};$('timeline').oninput=()=>{age=Number($('timeline').value);pause(true);};$('speed').onchange=()=>{speed=Number($('speed').value);};
for(const b of document.querySelectorAll('[data-time]'))b.onclick=()=>{age=Number(b.dataset.time);pause(false);};
for(const b of document.querySelectorAll('[data-preset]'))b.onclick=()=>{L={...L,...presetLooks[b.dataset.preset],camera:L.camera,compare:L.compare,reduced:L.reduced};sync();};
$('reset').onclick=()=>{L={...DEFAULTS,reduced:media.matches};sync();cameraPose();};
$('copy').onclick=async()=>{$('dial').hidden=false;$('dial').select();try{await navigator.clipboard.writeText($('dial').value);$('saved').textContent='Copied. Paste the dial-in into our chat; * marks changed controls.';}catch{$('saved').textContent='Settings selected. Press Ctrl+C to copy.';}};
$('camera').onchange=()=>{L.camera=$('camera').value;cameraPose();sync();};
sync();pause(paused);

const point=(num,y=.23)=>{const h=HEX_BY_NUM[num];return new THREE.Vector3((h.px-3255)/200,y,(h.py-2415)/200);};
const host=$('stage'), scene=new THREE.Scene();scene.background=new THREE.Color('#060711');
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;host.append(renderer.domElement);
const camera=new THREE.PerspectiveCamera(40,1,.1,250),controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.maxPolarAngle=Math.PI*.485;controls.minDistance=5;controls.maxDistance=55;
const environment=createArenaEnvironment(scene,{classicScenery:false});
const composer=new EffectComposer(renderer);composer.addPass(new RenderPass(scene,camera));const bloom=new UnrealBloomPass(new THREE.Vector2(1,1),L.bloom,.55,1);composer.addPass(bloom);const output=new OutputPass();composer.addPass(output);
function cameraPose(){const target=point(56,1.15);controls.target.copy(target);const positions={hero:[9,10,15],board:[18,24,29],top:[0,24,.1]};camera.position.copy(target).add(new THREE.Vector3(...positions[L.camera]));controls.update();}
cameraPose();
const observer=new ResizeObserver(()=>{const w=host.clientWidth,h=host.clientHeight;renderer.setSize(w,h);composer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();});observer.observe(host);
let arena=null;
new GLTFLoader().load(`${import.meta.env.BASE_URL}cosmic-arena/cosmic-arena.glb`,g=>{if(disposed){disposeTree(g.scene);return;}arena=g.scene;arena.scale.z=-1;polishArenaModel(arena);scene.add(arena);$('loading').hidden=true;ready=true;},undefined,()=>{$('loading').textContent='The arena could not load. Reload this local preview to retry.';});
const pawn=createStandee({...SPIRIT_DEFS.cosmic_ronin,color:'#6daaff'});scene.add(pawn.group);const pawnHome=point(56,.2);
const bats=Array.from({length:4},()=>{const bat=makeBat(),marker=makeMarker();scene.add(bat.root,marker.root);return {...bat,marker};});
// Fixed occupied hexes in this art study; only the prop drifts. A future port
// must drive these markers with the engine's hex immediately, as batStage does.
const homes=[46,65,38,74].map(n=>point(n,L.height));
const swarm=Array.from({length:16},()=>{const b=makeBat();scene.add(b.root);return b;});
const sonar=Array.from({length:3},()=>{const ring=new THREE.Mesh(new THREE.RingGeometry(.98,1,80).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:'#ba78ff',transparent:true,opacity:0,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}));scene.add(ring);return ring;});
const sparksGeo=new THREE.BufferGeometry(),sparkPositions=new Float32Array(90*3);sparksGeo.setAttribute('position',new THREE.BufferAttribute(sparkPositions,3));const sparks=new THREE.Points(sparksGeo,new THREE.PointsMaterial({color:'#ffce72',size:.065,transparent:true,opacity:0,depthWrite:false,blending:THREE.AdditiveBlending}));scene.add(sparks);
const impact=new THREE.Mesh(new THREE.RingGeometry(.88,1,64).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:'#ff526c',transparent:true,opacity:0,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending}));scene.add(impact);
const oldScene=new THREE.Scene();oldScene.background=new THREE.Color('#0a0b13');oldScene.add(new THREE.HemisphereLight('#c9d8ff','#39263c',3));
const oldLight=new THREE.DirectionalLight('#ffffff',3);oldLight.position.set(3,6,4);oldScene.add(oldLight);
const oldCamera=new THREE.PerspectiveCamera(40,1.2,.1,50);oldCamera.position.set(3.2,4.3,6);oldCamera.lookAt(0,1.2,0);
const oldRenderer=new THREE.WebGLRenderer({antialias:true});oldRenderer.setSize(180,150);oldRenderer.setPixelRatio(Math.min(devicePixelRatio,1.5));$('comparison').append(oldRenderer.domElement);
const oldBat=createBatStage(oldScene,{pointFor:(_,y)=>new THREE.Vector3(0,y,0),release:disposeTree});oldBat.update([{key:'reference',num:56,flight:0}]);
const acts=[['01 / THE ROOST WAKES','Something in the rafters.','A ribbon of silhouettes crosses the lights. Four hunters peel away and settle over their hexes.'],['02 / THE HUNT','They can hear the headliner.','A violet echo passes across the deck. The hunters bank and beat their wings, anchored to clear occupied hexes.'],['03 / THE BITE','One beat too late.',`A sharp dive, a crimson shock ring and a brief recoil: −${BAT_DAMAGE} Vibe. The bat returns to the stage.`],['04 / THE CATCH','Turn the scare into an encore.',`The Spirit steps into the bat’s hex. Gold sparks and +${BAT_FAN_GAIN} fans celebrate the catch, then the bat respawns.`],['05 / THE FINALE','Back into the night.','The four hunters rise into a loose spiral. The echoes fade and the arena is yours again.']];
function draw(t){
 const fixed=L.reduced?0:t,idx=t<3?0:t<7?1:t<10?2:t<15?3:4;
 $('act').textContent=acts[idx][0];$('moment').textContent=acts[idx][1];$('description').textContent=acts[idx][2];
 for(const b of document.querySelectorAll('[data-time]'))b.setAttribute('aria-current',String([...document.querySelectorAll('[data-time]')].indexOf(b)===idx));
 $('timeline').value=t;$('time').textContent=`${t.toFixed(1)} / 18s`;bloom.strength=L.bloom;
 pawn.group.position.copy(pawnHome);pawn.group.rotation.set(0,.3,0);
 // CATCH moves the Spirit to the bat, BITE moves the bat to the Spirit.
 const catchTravel=smooth((t-10)/.8)*(1-smooth((t-12.7)/.8));
 pawn.group.position.lerp(homes[1].clone().setY(.2),L.reduced?(t>=10.8&&t<12.7?1:0):catchTravel);
 const biteAge=t-7.65,catchAge=t-10.8,contact=idx===2?biteAge:catchAge;
 if(!L.reduced&&biteAge>0&&biteAge<.65)pawn.group.rotation.z=Math.sin(biteAge*29)*.12*Math.exp(-biteAge*5);
 for(let i=0;i<4;i++){
  const b=bats[i],home=homes[i].clone().setY(L.height),p=home.clone();let yaw=.45;
  const enter=L.entrance?smooth((t-i*.12)/2):1,exit=L.entrance?smooth((t-15-i*.15)/2.1):0;
  if(!L.reduced){p.x+=Math.sin(fixed*.75+i)*.15;p.z+=Math.cos(fixed*.85+i)*.15;p.y+=Math.sin(fixed*2.1+i)*.13;
   if(enter<1){p.x+=(1-enter)*(-8+i*4);p.y+=(1-enter)*7;p.z-=(1-enter)*8;}
   if(exit>0){p.x+=Math.sin(exit*5+i)*exit*4;p.z-=exit*8;p.y+=exit*8;}
  }
  b.root.visible=L.reduced?(t>=1&&t<17.5):enter>.03&&exit<.98;
  if(i===0&&idx===2){const dive=smooth((t-7)/.65),retreat=smooth((t-8)/1.2),amount=dive*(1-retreat);const target=pawnHome.clone().setY(1.6);p.lerp(target,L.reduced?0:amount);yaw=Math.atan2(target.x-home.x,target.z-home.z);}
  const caught=i===1&&catchAge>=0&&catchAge<1.1;b.root.visible&&=!caught;
  b.root.position.copy(p);b.root.rotation.set(0,yaw,L.reduced?0:Math.sin(fixed*1.4+i)*.18*L.bank);b.pose(fixed,L,i);
  b.marker.root.position.copy(home).setY(.235);b.marker.root.visible=b.root.visible;b.marker.shadow.visible=L.shadows;
 }
 for(let i=0;i<swarm.length;i++){const b=swarm[i],entry=t<3,u=entry?(t-i*.035)/3:(t-15-i*.025)/2.7;b.root.visible=L.entrance&&!L.reduced&&u>0&&u<1&&(t<3||t>=15);if(!b.root.visible)continue;const theta=i*2.4+u*5;b.root.position.set(Math.cos(theta)*(7-2*u),3+Math.sin(i)*.7+(entry?(1-u)*5:u*7),Math.sin(theta)*4-3-u*5);b.root.rotation.set(0,theta+.8,Math.sin(theta)*.4);b.pose(fixed,{...L,size:.22+i%4*.045},i);}
 for(let i=0;i<3;i++){const r=sonar[i],u=L.reduced?.35:((t+i*.6)%2.4)/2.4;r.position.copy(pawnHome).setY(.25+i*.003);r.scale.setScalar(1+u*6);r.material.opacity=L.sonar&&idx===1?(L.reduced?.12:(1-u)*.23):0;}
 const active=(idx===2||idx===3)&&contact>=0&&contact<1.2;
 const color=idx===2?'#ff526c':'#ffd478';impact.position.copy(pawn.group.position).setY(.255);impact.scale.setScalar(L.reduced?1.2:.4+Math.max(0,contact)*2.8);impact.material.color.set(color);impact.material.opacity=active?(L.reduced?.35:(1-contact/1.2)*.7):0;
 sparks.material.color.set(color);sparks.material.opacity=active&&!L.reduced?Math.max(0,1-contact/1.2):0;sparksGeo.setDrawRange(0,Math.round(60*L.particles));
 for(let i=0;i<90;i++){const a=i*2.3999,v=.7+(i%7)*.25,dt=Math.max(0,contact);sparkPositions[i*3]=pawn.group.position.x+Math.cos(a)*dt*v;sparkPositions[i*3+1]=1.4+Math.sin(i*17)*dt*2-dt*dt*.8;sparkPositions[i*3+2]=pawn.group.position.z+Math.sin(a)*dt*v;}sparksGeo.attributes.position.needsUpdate=true;
 // Keep culling in sync with the particle buffer as the catch moves its origin.
 sparksGeo.computeBoundingSphere();
 const pop=$('popup');pop.hidden=!active;pop.textContent=idx===2?`−${BAT_DAMAGE} VIBE`:`+${BAT_FAN_GAIN} FANS`;pop.style.color=color;
 const screen=pawn.group.position.clone().add(new THREE.Vector3(0,3.7,0)).project(camera);pop.style.left=`${(screen.x*.5+.5)*host.clientWidth}px`;pop.style.top=`${(-screen.y*.5+.5)*host.clientHeight}px`;pop.style.transform='translate(-50%,-50%)';
 oldBat.tick(fixed,{reduced:L.reduced});if(L.compare)oldRenderer.render(oldScene,oldCamera);
 composer.render();
}
let previous=performance.now(),raf;
function frame(now){if(disposed)return;const dt=Math.min((now-previous)/1000,.05);previous=now;if(ready&&!paused&&!document.hidden)age=(age+dt*speed)%18;controls.update();draw(age);raf=requestAnimationFrame(frame);}
raf=requestAnimationFrame(frame);
function preference(){if(media.matches){L.reduced=true;pause(true);sync();}}media.addEventListener('change',preference);
window.addEventListener('pagehide',()=>{disposed=true;cancelAnimationFrame(raf);observer.disconnect();media.removeEventListener('change',preference);controls.dispose();oldBat.dispose();oldRenderer.dispose();pawn.dispose();environment.dispose();disposeTree(scene);bloom.dispose();output.dispose();composer.dispose();renderer.dispose();},{once:true});
// Small read-only hook for visual QA, no dependency from the live game.
window.batStudy={get state(){return {age,paused,ready,settings:{...L},ruleStepMs:BAT_STEP_MS,batCount:bats.length};}};
